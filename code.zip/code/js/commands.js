if (annyang) {
    // Let's define a command.
    var commands = {
        'hi': function() { 
            alert('Hi, You can now speak to navigate around this website. Try it now by saying "go to ..."'); 
        },
        'go to about you': function() { 
            window.location.href='./ay.html'; 
        },
        'go to work tools': function() { 
            window.location.href='./tools.html'; 
        },
        'go to crowd around': function() { 
            window.location.href='./ca.html'; 
        },
        'go to home': function() { 
            window.location.href='./vzweb.html'; 
        },
        'select parking slot': function() { 
            window.location.href='./parking.html'; 
        },
        'select cab booking': function() { 
            window.location.href='./cab.html'; 
        },
        'select travel request': function() { 
            window.location.href='./travel.html'; 
        },
        'select travel request': function() { 
            window.location.href='./travel.html'; 
        },
        'open work tools': function() { 
            $('.dropdown').addClass('open');
        },
         'close work tools': function() { 
            $('.dropdown').removeClass('open');
        },
    };

    // Add our commands to annyang
    annyang.addCommands(commands);

    // Start listening.
    annyang.start();
}